# Hambo's Games — Test Build

This is the first website prototype for testing on GitHub Pages.

## Included
- Responsive dark-blue retro website
- Home, Games, New Games, and About pages
- No Favorites page
- 10-game library
- Featured Games section
- Playable prototype screens for all 10 games
- Browser save system using localStorage
- Big Bass Fishing includes a starter Fish Collection counter
- Mobile-friendly on-screen controls
- No external libraries or downloads required

## GitHub Pages
Upload `index.html` to a repository. GitHub Pages can serve it directly as the site's entry page.

## Important
This is a **prototype/test build**, not the final versions of the 10 games. The larger games (Sand Box and Big Bass Fishing) are represented by playable early prototypes so the website and save architecture can be tested before full game development.
